# Campus Event Management & Feedback Analyzer

A syllabus-oriented Python OOP project using HTML, CSS, CSV files, Pandas, NumPy, and Matplotlib. It does **not** use Flask, Django, Node.js, React, or separate JavaScript files.

## Features
- Student sign-up/login using student code + email (both required).
- Admin login with role-protected admin pages.
- Event CRUD, search/filter, maximum participant limit.
- Student event registration/cancellation; duplicate registration prevention.
- Feedback ratings (1–5), comments, one feedback per student/event.
- Admin dashboard, event/student/registration/feedback management.
- Pandas/NumPy analytics and Matplotlib charts regenerated after successful data changes.
- CSV persistence and exception handling.

## Requirements
- Python 3.10+
- VS Code (recommended)

## Setup (Windows PowerShell)
```powershell
cd Campus_Event_Management
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Optional: run `python seed_demo.py` before starting the server to create sample events and student accounts. Then run `python app.py` and open `http://127.0.0.1:8000`.

## Demo admin
- Student code: `ADMIN001`
- Email: `admin.demo@gmail.com`

For a classroom demo, admin access uses a fixed demo account. Change it in `config.py` before using the app beyond a local demo. Student accounts are created through the Sign Up page. Student code + email is basic demonstration authentication, not strong production security.

## Data and charts
CSV data lives in `data/`. Generated PNG charts live in `charts/`. The charts and dashboard statistics are recalculated after event, registration, student, or feedback changes and when the dashboard is opened.

## Notes
- Use the app through the Python server, not by opening HTML files directly.
- The app uses Python's built-in `http.server`. This is suitable for a local academic demonstration, not a production deployment.
- A student may submit feedback only once for each event and only after registering. Adjust eligibility policy in `services/feedback_service.py` if your instructor requires a different rule.


Updated login: choose Student or Admin and provide name, ID and Gmail address. Demo admin: Administrator / ADMIN001 / admin.demo@gmail.com. Demo student: Aarav Sharma / BWU/MCA/26/001 / aarav.demo@gmail.com.

## Password login
- Student and admin accounts now require a password.
- Passwords are stored as salted PBKDF2-HMAC-SHA256 hashes (not plain text).
- Password rule: at least 8 characters with uppercase, lowercase and a number.
- Included demo student password: `Student@12345`.
- Included demo admin account: `Campus Admin / ADMIN002 / campus.admin@gmail.com / Admin@12345`.
- Built-in demo administrator: `Administrator / ADMIN001 / admin.demo@gmail.com / Admin@12345`.
- Change demo passwords and credentials before sharing the project.
