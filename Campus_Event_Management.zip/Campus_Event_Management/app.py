from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from http.cookies import SimpleCookie
from html import escape
from pathlib import Path
import secrets
from datetime import date
from config import HOST, PORT, TEMPLATES_DIR, STATIC_DIR, CHARTS_DIR, SESSION_COOKIE
from services.file_service import initialize_files, read_records, write_records
from services.auth_service import login, create_student, create_admin
from services.event_service import all_events, save_event, delete_event, find_event
from services.registration_service import all_registrations, register, cancel_registration, active_for_event
from services.feedback_service import all_feedback, submit_feedback, update_feedback, delete_feedback
from analytics.analysis import dashboard_stats, event_table_rows
from analytics.charts import refresh_charts

SESSIONS = {}

def esc(v):
    return escape(str(v if v is not None else ""), quote=True)

def flash_html(msg, kind="success"):
    return f'<div class="flash {esc(kind)}">{esc(msg)}</div>' if msg else ""

def template(name):
    return (TEMPLATES_DIR / name).read_text(encoding="utf-8")

def table(headers, rows, empty="No records found."):
    if not rows:
        return f'<div class="empty"><strong>Nothing here yet</strong>{esc(empty)}</div>'
    h = "<thead><tr>" + "".join(f"<th>{esc(x)}</th>" for x in headers) + "</tr></thead>"
    b = "<tbody>" + "".join("<tr>" + "".join(f"<td>{x}</td>" for x in r) + "</tr>" for r in rows) + "</tbody>"
    return '<div class="table-wrap"><table>' + h + b + '</table></div>'

def stat(label, value, icon, color=""):
    return f'<div class="stat-card"><div><div class="stat-label">{esc(label)}</div><div class="stat-value">{esc(value)}</div></div><div class="stat-icon {color}">{icon}</div></div>'

def link(url, text, cls="btn btn-primary"):
    return f'<a class="{cls}" href="{esc(url)}">{text}</a>'

def render_page(title, subtitle, body, user, flash, active):
    role = user.get("role", "guest")
    if role == "admin":
        items = [("/admin","▦","Dashboard"),("/admin/events","▣","Manage Events"),("/admin/students","♙","Students"),("/registrations","☷","Registrations"),("/feedback","☆","Feedback & Analytics")]
    else:
        items = [("/student","▦","Dashboard"),("/events","▣","Browse Events"),("/registrations","☷","My Registrations"),("/feedback","☆","Feedback"),("/profile","♙","Profile")]
    nav = '<nav class="nav-list">' + "".join(
        f'<a class="nav-link {"active" if active == u else ""}" href="{u}"><span class="nav-ico">{i}</span><span class="nav-text">{t}</span></a>'
        for u,i,t in items) + "</nav>"
    page = template("base.html")
    replacements = {"{{TITLE}}":esc(title),"{{SUBTITLE}}":esc(subtitle),"{{NAV}}":nav,
        "{{USER}}":esc(user.get("name","Guest")),"{{ROLE}}":esc(role),
        "{{INITIAL}}":esc((user.get("name") or "G")[:1].upper()),
        "{{FLASH}}":flash_html(flash[0],flash[1]) if flash else "","{{BODY}}":body}
    for k,v in replacements.items():
        page = page.replace(k,v)
    return page

def event_card(e, user, registered=None):
    registered = registered or set()
    eid = e["event_id"]
    count = len(active_for_event(eid))
    limit = int(e["max_participants"])
    seats = max(0,limit-count)
    if user.get("role") == "admin":
        action = link("/admin/events?edit="+eid,"Edit event","btn btn-secondary")
    elif eid in registered:
        action = '<span class="status">Registered</span>'
    elif seats == 0:
        action = '<span class="status cancelled">Event full</span>'
    else:
        action = f'<form method="post" action="/register"><input type="hidden" name="event_id" value="{esc(eid)}"><button class="btn btn-purple">Register now →</button></form>'
    initials = "".join(w[0] for w in e["event_name"].split()[:2]).upper()
    desc = e.get("description") or "Join fellow students and take part in this campus experience."
    phase = "Upcoming" if e["date"] >= date.today().isoformat() else "Past event"
    return (f'<article class="event-card"><div><div class="event-title-row"><div class="event-avatar">{esc(initials)}</div><div><h3 class="event-title">{esc(e["event_name"])}</h3><div class="table-sub">{esc(eid)}</div></div></div>'
        f'<p class="event-desc">{esc(desc)}</p><div class="event-meta"><span>▣ {esc(e["date"])}</span><span>⌖ {esc(e["venue"])}</span><span>♙ {count}/{limit} participants</span><span>◉ {seats} seats left</span></div>'
        f'<div class="tag-row"><span class="tag">Campus Event</span><span class="tag purple">{phase}</span></div></div><div class="event-actions">{action}</div></article>')

class Handler(BaseHTTPRequestHandler):
    server_version = "CampusEvents/1.0"
    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))
    def session(self):
        c = SimpleCookie()
        try:
            c.load(self.headers.get("Cookie",""))
            token = c[SESSION_COOKIE].value if SESSION_COOKIE in c else ""
        except Exception:
            token = ""
        return token, SESSIONS.get(token)
    def send_page(self, content, status=200, ctype="text/html; charset=utf-8", extra=None):
        data = content if isinstance(content,bytes) else content.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type",ctype)
        self.send_header("Content-Length",str(len(data)))
        self.send_header("X-Content-Type-Options","nosniff")
        if extra:
            for k,v in extra.items(): self.send_header(k,v)
        self.end_headers()
        self.wfile.write(data)
    def redirect(self, path, message="", kind="success"):
        token,user = self.session()
        if message and user is not None: user["_flash"] = (message,kind)
        self.send_response(303); self.send_header("Location",path); self.send_header("Content-Length","0"); self.end_headers()
    def form(self):
        try:
            n = min(int(self.headers.get("Content-Length","0")),1000000)
            parsed = parse_qs(self.rfile.read(n).decode("utf-8","replace"),keep_blank_values=True)
            return {k:v[-1] for k,v in parsed.items()}
        except Exception: return {}
    def require(self, role=None):
        token,user = self.session()
        if not user:
            self.redirect("/login","Please sign in to continue.","error"); return None
        if role and user.get("role") != role:
            self.redirect("/admin" if user.get("role")=="admin" else "/student","You do not have permission.","error"); return None
        return user
    def page(self,title,subtitle,body,user,active):
        flash = user.pop("_flash",None)
        self.send_page(render_page(title,subtitle,body,user,flash,active))
    def do_GET(self):
        parsed = urlparse(self.path); path=parsed.path; q=parse_qs(parsed.query)
        if path == "/static/css/style.css":
            try: self.send_page((STATIC_DIR/"css"/"style.css").read_bytes(),ctype="text/css; charset=utf-8")
            except OSError: self.send_page("CSS not found",404)
            return
        if path.startswith("/charts/"):
            name=path.rsplit("/",1)[-1]
            if name not in ("event_participation.png","event_ratings.png","rating_distribution.png"):
                self.send_page("Not found",404); return
            try: self.send_page((CHARTS_DIR/name).read_bytes(),ctype="image/png",extra={"Cache-Control":"no-store"})
            except OSError: self.send_page("Chart not found",404)
            return
        if path in ("/","/login"):
            _,u=self.session()
            if u: self.redirect("/admin" if u.get("role")=="admin" else "/student"); return
            self.send_page(template("login.html").replace("{{FLASH}}","")); return
        if path=="/signup":
            role = parse_qs(parsed.query).get("role", ["student"])[0]
            page = template("signup.html").replace("{{FLASH}}", "")
            # Role is selected by the query string and reflected by the form's own script.
            self.send_page(page); return
        user=self.require()
        if not user:return
        role=user["role"]
        if path=="/admin":
            if role!="admin": self.redirect("/student","Admin access only.","error"); return
            refresh_charts(); s=dashboard_stats()
            high=f'{esc(s["highest"][0])} · {s["highest"][1]}/5' if s["highest"] else "No ratings yet"
            low=f'{esc(s["lowest"][0])} · {s["lowest"][1]}/5' if s["lowest"] else "No ratings yet"
            body=(f'<div class="grid stats-grid">{stat("Total events",s["total_events"],"▣","purple")}{stat("Active registrations",s["active_registrations"],"♙")}{stat("Feedback received",s["total_feedback"],"☆","orange")}{stat("Average rating",str(s["overall_rating"])+"/5" if s["overall_rating"] is not None else "N/A","★","blue")}</div>'
            f'<div class="hero-banner"><h2>Your campus, in one view.</h2><p>Track participation, listen to student feedback, and make every event better.</p><div class="hero-meta"><span>{s["unique_participants"]} unique participants</span><span>Live file-based analytics</span></div></div>'

            f'<div class="grid two-col"><div class="card"><h2>Highest-rated event</h2><p>{high}</p></div><div class="card"><h2>Lowest-rated event</h2><p>{low}</p></div></div>'
            f'<div class="card"><div class="section-head"><h2>Event overview</h2>{link("/admin/events","Manage events","btn btn-primary btn-small")}</div>{self.event_table()}</div>'
            '<div class="grid chart-grid"><div class="card chart-card"><h3>Event-wise participation</h3><img class="chart-img" src="/charts/event_participation.png" alt="Event participation chart"></div><div class="card chart-card"><h3>Average rating by event</h3><img class="chart-img" src="/charts/event_ratings.png" alt="Average ratings chart"></div><div class="card chart-card"><h3>Rating distribution</h3><img class="chart-img" src="/charts/rating_distribution.png" alt="Rating histogram"></div></div>')
            self.page("Admin Dashboard","Overview of campus events and feedback.",body,user,"/admin"); return
        if path=="/student":
            if role!="student": self.redirect("/admin"); return
            mine=[r for r in all_registrations() if r["student_id"]==user["student_id"] and r["status"]=="Registered"]
            fbs=[r for r in all_feedback() if r["student_id"]==user["student_id"]]
            upcoming=[e for e in all_events() if e["date"]>=date.today().isoformat()]
            ids={r["event_id"] for r in mine}
            cards="".join(event_card(e,user,ids) for e in upcoming[:5]) or '<div class="empty"><strong>No upcoming events</strong>Check back later for new campus events.</div>'
            body=(f'<div class="grid stats-grid">{stat("My registrations",len(mine),"▣","purple")}{stat("Completed events",sum(1 for r in mine if (find_event(r["event_id"]) or {}).get("date","9999")<date.today().isoformat()),"✓")}{stat("Feedback submitted",len(fbs),"☆","orange")}{stat("Events available",len(upcoming),"◷","blue")}</div>'
            '<div class="hero-banner"><h2>Discover amazing campus events.</h2><p>Learn something new, meet your community, and share your experience.</p><div class="hero-meta"><span>'+str(len(upcoming))+' upcoming events</span><span>Winner can get a mega prize.</span></div></div>'
            f'<div class="card"><div class="section-head"><div><h2>Featured events</h2><p>Find your next campus experience</p></div>{link("/events","Browse all events","btn btn-secondary btn-small")}</div><div class="event-list">{cards}</div></div>')
            self.page("Student Dashboard","",body,user,"/student"); return
        if path=="/events":
            events=all_events(); term=q.get("q",[""])[0].strip().lower(); start=q.get("start",[""])[0]; end=q.get("end",[""])[0]
            events=[e for e in events if (not term or term in e["event_name"].lower() or term in e["event_id"].lower() or term in e["venue"].lower()) and (not start or e["date"]>=start) and (not end or e["date"]<=end)]
            ids={r["event_id"] for r in all_registrations() if r["student_id"]==user.get("student_id") and r["status"]=="Registered"} if role=="student" else set()
            cards="".join(event_card(e,user,ids) for e in events) or '<div class="empty"><strong>No matching events</strong>Try changing your search or date filters.</div>'
            body=(f'<div class="card"><div class="section-head"><div><h2>Browse campus events</h2><p>Search by event name, ID or venue, and filter by date.</p></div></div><form class="filters" method="get"><input class="filter-search" name="q" placeholder="Search events..." value="{esc(q.get("q",[""])[0])}"><label>From<input type="date" name="start" value="{esc(start)}"></label><label>To<input type="date" name="end" value="{esc(end)}"></label><button class="btn btn-primary">Apply filters</button><a class="btn btn-secondary" href="/events">Reset</a></form><div class="event-list">{cards}</div></div>')
            self.page("Browse Events","Explore events happening across your campus.",body,user,"/events"); return
        if path=="/registrations":
            regs=all_registrations()
            if role=="student": regs=[r for r in regs if r["student_id"]==user["student_id"]]
            term=q.get("q",[""])[0].lower().strip(); students={s["student_id"]:s for s in read_records("students")}; evmap={e["event_id"]:e for e in all_events()}
            if term: regs=[r for r in regs if term in r["event_id"].lower() or term in r["registration_id"].lower() or term in students.get(r["student_id"],{}).get("name","").lower() or term in students.get(r["student_id"],{}).get("email","").lower() or term in evmap.get(r["event_id"],{}).get("event_name","").lower()]
            rows=[]
            for r in regs:
                s=students.get(r["student_id"],{}); e=evmap.get(r["event_id"],{})
                action=""
                if r["status"]=="Registered": action=f'<form method="post" action="/cancel-registration"><input type="hidden" name="registration_id" value="{esc(r["registration_id"])}"><button class="btn btn-danger btn-small">Cancel</button></form>'
                rows.append([esc(r["registration_id"]),esc(s.get("name","Unknown")),esc(s.get("email","")),esc(e.get("event_name",r["event_id"])),esc(r["registration_date"]),f'<span class="status {"cancelled" if r["status"]=="Cancelled" else ""}">{esc(r["status"])}</span>',action])
            body=f'<div class="card"><div class="section-head"><div><h2>{"My registrations" if role=="student" else "All registrations"}</h2><p>Track and manage event registrations.</p></div></div><form class="filters" method="get"><input class="filter-search" name="q" value="{esc(q.get("q",[""])[0])}" placeholder="Search name, email, event or ID"><button class="btn btn-primary">Search</button></form>{table(["Registration ID","Student","Email","Event","Date","Status","Action"],rows,"No registrations match this search.")}</div>'
            self.page("Registrations","Review registration status and participant records.",body,user,"/registrations"); return
        if path=="/feedback":
            if role=="student":
                regs={r["event_id"] for r in all_registrations() if r["student_id"]==user["student_id"] and r["status"]=="Registered"}
                sent={r["event_id"] for r in all_feedback() if r["student_id"]==user["student_id"]}
                opts="".join(f'<option value="{esc(e["event_id"])}">{esc(e["event_name"])} ({esc(e["date"])})</option>' for e in all_events() if e["event_id"] in regs and e["event_id"] not in sent)
                form=(f'<div class="card"><div class="section-head"><div><h2>Share your experience</h2><p>Tell us what you thought about the event.</p></div></div><form class="form-stack" method="post" action="/feedback"><label>Event<select name="event_id" required><option value="">Choose an event</option>{opts}</select></label><label>Rating<select name="rating" required><option value="">Select rating</option><option value="5">5 — Excellent</option><option value="4">4 — Very good</option><option value="3">3 — Good</option><option value="2">2 — Fair</option><option value="1">1 — Poor</option></select></label><label>Your review<textarea name="comment" maxlength="1500" required placeholder="Share your experience..."></textarea></label><button class="btn btn-primary">Submit feedback</button></form></div>' if opts else '<div class="card"><div class="empty"><strong>No feedback pending</strong>You need an active registration and may submit feedback once per event.</div></div>')
                rows=[r for r in all_feedback() if r["student_id"]==user["student_id"]]
            else:
                form=""
                rows=all_feedback()
            term=q.get("q",[""])[0].lower().strip()
            rating_filter=q.get("rating",[""])[0]
            students={st["student_id"]:st for st in read_records("students")}
            evmap={e["event_id"]:e for e in all_events()}
            if term:
                rows=[r for r in rows if term in r["comment"].lower() or term in r["event_id"].lower() or term in students.get(r["student_id"],{}).get("name","").lower() or term in students.get(r["student_id"],{}).get("email","").lower() or term in evmap.get(r["event_id"],{}).get("event_name","").lower()]
            if rating_filter in ("1","2","3","4","5"):
                rows=[r for r in rows if str(r["rating"])==rating_filter]
            rows=sorted(rows,key=lambda x:x.get("feedback_date",""),reverse=True)
            cards=[]
            for r in rows:
                st=students.get(r["student_id"],{}); ev=evmap.get(r["event_id"],{})
                stars=int(r["rating"])
                actions=""
                if role=="admin":
                    option_html="".join(f'<option value="{n}" {"selected" if n==stars else ""}>{n} stars</option>' for n in range(5,0,-1))
                    actions=(f'<details class="review-edit"><summary>Edit review</summary><form method="post" action="/admin/feedback/update" class="form-stack compact-edit"><input type="hidden" name="feedback_id" value="{esc(r["feedback_id"])}"><label>Rating<select name="rating">{option_html}</select></label><label>Comment<textarea name="comment" required maxlength="1500">{esc(r["comment"])}</textarea></label><button class="btn btn-secondary btn-small">Save changes</button></form></details><form method="post" action="/admin/feedback/delete"><input type="hidden" name="feedback_id" value="{esc(r["feedback_id"])}"><button class="btn btn-danger btn-small">Delete review</button></form>')
                cards.append(f'<article class="review-card"><div class="review-person"><div class="review-avatar">{esc((st.get("name") or "?")[:1].upper())}</div><div><strong>{esc(st.get("name","Unknown"))}</strong><small>{esc(r["feedback_date"])}</small></div></div><div class="review-stars">{"★"*stars}<span>{"☆"*(5-stars)}</span><b>{stars}.0</b></div><p class="review-comment">{esc(r["comment"])}</p><div class="review-event"><div class="event-mini-avatar">▣</div><div><strong>{esc(ev.get("event_name",r["event_id"]))}</strong><small>{esc(ev.get("category","Campus event"))}</small></div><span class="review-event-id">{esc(r["event_id"])}</span></div><div class="review-actions">{actions}</div></article>')
            if role=="admin":
                refresh_charts()
                stats=dashboard_stats()
                avg=stats["overall_rating"] if stats["overall_rating"] is not None else 0
                count=stats["total_feedback"]
                # Monthly feedback bars are generated from the current CSV records.
                summary=(f'<div class="feedback-overview"><div class="rating-summary"><h3>Ratings</h3><div class="rating-big"><strong>{avg:.1f}</strong><span>/5</span></div><p>{count:,} feedback reviews</p><div class="rating-breakdown">Average rating across all campus events</div></div><div class="rating-statistics"><div class="section-head"><h3>Feedback Statistics</h3><span class="tag purple">Live · All time</span></div><img src="/charts/feedback_monthly.png?v={count}-{date.today().isoformat()}" alt="Monthly feedback statistics" class="feedback-chart"></div></div>'
                +f'<div class="feedback-highlow"><div><small>Highest-rated event</small><strong>{esc(stats["highest"][0]) if stats["highest"] else "Not rated yet"}</strong><span>{stats["highest"][1]}/5' if stats["highest"] else '<span>No ratings yet</span>'
                +'</span></div><div><small>Lowest-rated event</small><strong>'+ (esc(stats["lowest"][0]) if stats["lowest"] else "Not rated yet")+'</strong><span>'+(f'{stats["lowest"][1]}/5' if stats["lowest"] else 'No ratings yet')+'</span></div></div>')
            else:
                summary=""
            content='<div class="review-grid">'+("".join(cards) if cards else '<div class="empty"><strong>No reviews found</strong>Try changing your filters.</div>')+'</div>' 
            rating_options="".join(f'<option value="{n}" {"selected" if rating_filter==str(n) else ""}>{n} stars</option>' for n in range(5,0,-1))
            body=f"""{form}{summary}<div class="card feedback-list"><div class="section-head"><div><h2>{"Student Reviews" if role=="admin" else "My feedback"}</h2><p>{"Read, edit or remove feedback submitted by students." if role=="admin" else "Your submitted event reviews."}</p></div><span class="tag">{len(rows)} reviews</span></div><form class="filters" method="get"><input class="filter-search" name="q" value="{esc(term)}" placeholder="Search student, event or comment"><select name="rating"><option value="">All ratings</option>{rating_options}</select><button class="btn btn-primary">Apply filters</button><a class="btn btn-secondary" href="/feedback">Reset</a></form>{content}</div>"""
            self.page("Feedback & Analytics" if role=="admin" else "Feedback","Student ratings and event reviews.",body,user,"/feedback"); return
        if path=="/admin/events":
            if role!="admin": self.redirect("/student","Admin access only.","error"); return
            term=q.get("q",[""])[0].lower().strip(); events=all_events()
            if term: events=[e for e in events if term in e["event_name"].lower() or term in e["event_id"].lower() or term in e["venue"].lower()]
            edit=q.get("edit",[""])[0]; e=find_event(edit) if edit else None
            form=self.event_form(e); stats={r["event_id"]:r for r in event_table_rows()}; rows=[]
            for ev in events:
                st=stats.get(ev["event_id"],{})
                actions=f'<div class="form-actions"><a class="btn btn-secondary btn-small" href="/admin/events?edit={esc(ev["event_id"])}">Edit</a><form method="post" action="/admin/events/delete"><input type="hidden" name="event_id" value="{esc(ev["event_id"])}"><button class="btn btn-danger btn-small">Delete</button></form></div>'
                rows.append([f'<span class="table-title">{esc(ev["event_name"])}</span><div class="table-sub">{esc(ev["event_id"])}</div>',esc(ev["date"]),esc(ev["venue"]),f'{st.get("participants",0)}/{esc(ev["max_participants"])}',esc(st.get("average_rating") if st.get("average_rating") is not None else "N/A"),actions])
            body=f'{form}<div class="card"><div class="section-head"><div><h2>All events</h2><p>Manage event details, capacity and availability.</p></div></div><form class="filters" method="get"><input class="filter-search" name="q" value="{esc(q.get("q",[""])[0])}" placeholder="Search event name, ID or venue"><button class="btn btn-primary">Search</button><a class="btn btn-secondary" href="/admin/events">Reset</a></form>{table(["Event","Date","Venue","Participants","Avg. rating","Actions"],rows,"No events found.")}</div>'
            self.page("Manage Events","Create and maintain campus event listings.",body,user,"/admin/events"); return
        if path=="/admin/students":
            if role!="admin": self.redirect("/student","Admin access only.","error"); return
            rows=read_records("students"); term=q.get("q",[""])[0].lower().strip()
            if term: rows=[s for s in rows if term in s["name"].lower() or term in s["email"].lower() or term in s["student_code"].lower()]
            out=[]
            for s in rows:
                action=f'<form method="post" action="/admin/students/delete"><input type="hidden" name="student_id" value="{esc(s["student_id"])}"><button class="btn btn-danger btn-small">Delete</button></form>'
                out.append([esc(s["student_id"]),esc(s["name"]),esc(s["student_code"]),esc(s["email"]),action])
            body=f'<div class="card"><div class="section-head"><div><h2>Student directory</h2><p>Student accounts created through sign up.</p></div></div><form class="filters" method="get"><input class="filter-search" name="q" value="{esc(q.get("q",[""])[0])}" placeholder="Search name, code or email"><button class="btn btn-primary">Search</button></form>{table(["Student ID","Name","Student code","Email","Actions"],out,"No student accounts found.")}</div><div class="note">Deleting a student with registration or feedback history is blocked to preserve records.</div>'
            self.page("Manage Students","Search student accounts and manage records.",body,user,"/admin/students"); return
        if path=="/profile":
            if role!="student": self.redirect("/admin"); return
            body=f'<div class="card"><div class="section-head"><h2>Student profile</h2></div><div class="form-grid"><label>Full name<input value="{esc(user["name"])}" readonly></label><label>Student code<input value="{esc(user["student_code"])}" readonly></label><label class="span-all">Email address<input value="{esc(user["email"])}" readonly></label></div><p class="muted-text">Profile fields are read-only in this version.</p></div>'
            self.page("Profile","Your student account details.",body,user,"/profile"); return
        self.send_page("Page not found",404)

    def event_form(self,e=None):
        def val(k): return esc(e.get(k,"")) if e else ""
        editing=e is not None
        return (f'<div class="card"><div class="section-head"><div><h2>{"Edit event" if editing else "Create an event"}</h2><p>Enter event details and set the participant limit.</p></div>{link("/admin/events","Cancel edit","btn btn-secondary btn-small") if editing else ""}</div>'
        f'<form method="post" action="/admin/events/save" class="form-grid"><input type="hidden" name="event_id" value="{val("event_id")}"><label>Event name<input name="event_name" required pattern="[A-Za-z .&()\'-]+" value="{val("event_name")}" placeholder="e.g. Coding Workshop"></label><label>Event date<input type="date" name="date" required value="{val("date")}"></label><label>Venue<input name="venue" required value="{val("venue")}" placeholder="e.g. Seminar Hall"></label><label>Maximum participants<input type="number" min="1" name="max_participants" required value="{val("max_participants")}" placeholder="100"></label><label class="span-all">Description<textarea name="description" maxlength="1000" placeholder="Describe the event...">{val("description")}</textarea></label><div class="form-actions span-all"><button class="btn btn-primary">{"Save changes" if editing else "Create event"} →</button></div></form></div>')

    def event_table(self):
        rows=[]
        for e in event_table_rows():
            rows.append([f'<span class="table-title">{esc(e["event_name"])}</span><div class="table-sub">{esc(e["event_id"])}</div>',esc(e["date"]),esc(e["venue"]),f'{e["participants"]}/{esc(e["max_participants"])}',esc(e["average_rating"] if e["average_rating"] is not None else "N/A")])
        return table(["Event","Date","Venue","Participants","Avg. rating"],rows,"Create your first event to see it here.")

    def do_POST(self):
        path=urlparse(self.path).path; data=self.form()
        if path=="/login":
            try:
                user=login(data.get("student_code",""),data.get("email",""),data.get("name",""),data.get("role",""),data.get("password",""))
                token=secrets.token_urlsafe(32); SESSIONS[token]=user
                self.send_response(303); self.send_header("Location","/admin" if user["role"]=="admin" else "/student")
                self.send_header("Set-Cookie",f"{SESSION_COOKIE}={token}; HttpOnly; SameSite=Lax; Path=/")
                self.send_header("Content-Length","0"); self.end_headers()
            except ValueError as exc:
                self.send_page(template("login.html").replace("{{FLASH}}",flash_html(str(exc),"error")),400)
            return
        if path=="/signup":
            role = data.get("role", "student").strip().lower()
            try:
                if role == "admin":
                    create_admin(data.get("name",""), data.get("email",""), data.get("student_code",""), data.get("password",""))
                    message = "Admin account created. Please sign in using Admin Login."
                else:
                    create_student(data.get("name",""),data.get("email",""),data.get("student_code",""),data.get("password",""))
                    message = "Student account created. Please sign in using Student Login."
                self.send_page(template("login.html").replace("{{FLASH}}",flash_html(message,"success")))
            except ValueError as exc:
                page = template("signup.html")
                # Preserve the selected account type when showing validation errors.
                page = page.replace('value="student"', f'value="{esc("admin" if role == "admin" else "student")}"', 1)
                page = page.replace("{{FLASH}}", flash_html(str(exc), "error"))
                self.send_page(page,400)
            return
        if path=="/logout":
            token,_=self.session()
            if token: SESSIONS.pop(token,None)
            self.send_response(303); self.send_header("Location","/login"); self.send_header("Set-Cookie",f"{SESSION_COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0"); self.send_header("Content-Length","0"); self.end_headers(); return
        user=self.require()
        if not user:return
        role=user["role"]
        try:
            if path=="/register":
                if role!="student": raise ValueError("Only students can register for events.")
                register(user["student_id"],data.get("event_id","")); refresh_charts(); self.redirect("/registrations","Registration completed successfully."); return
            if path=="/cancel-registration":
                cancel_registration(data.get("registration_id",""),user["student_id"] if role=="student" else None); refresh_charts(); self.redirect("/registrations","Registration cancelled."); return
            if path=="/feedback":
                if role!="student": raise ValueError("Only students can submit feedback here.")
                submit_feedback(user["student_id"],data.get("event_id",""),data.get("rating",""),data.get("comment","")); refresh_charts(); self.redirect("/feedback","Thank you! Your feedback has been saved."); return
            if path.startswith("/admin/"):
                if role!="admin": self.redirect("/student","Admin access only.","error"); return
                if path=="/admin/events/save":
                    save_event(data,data.get("event_id") or None); refresh_charts(); self.redirect("/admin/events","Event saved successfully."); return
                if path=="/admin/events/delete":
                    delete_event(data.get("event_id","")); refresh_charts(); self.redirect("/admin/events","Event deleted."); return
                if path=="/admin/students/delete":
                    sid=data.get("student_id","")
                    if any(r["student_id"]==sid for r in all_registrations()) or any(r["student_id"]==sid for r in all_feedback()):
                        raise ValueError("Cannot delete a student with registration or feedback history.")
                    rows=read_records("students")
                    if not any(s["student_id"]==sid for s in rows): raise ValueError("Student not found.")
                    write_records("students",[s for s in rows if s["student_id"]!=sid]); self.redirect("/admin/students","Student deleted."); return
                if path=="/admin/feedback/update":
                    update_feedback(data.get("feedback_id",""),data.get("rating",""),data.get("comment","")); refresh_charts(); self.redirect("/feedback","Feedback updated."); return
                if path=="/admin/feedback/delete":
                    delete_feedback(data.get("feedback_id","")); refresh_charts(); self.redirect("/feedback","Feedback deleted."); return
            raise ValueError("Unknown action.")
        except ValueError as exc:
            target={"/register":"/events","/cancel-registration":"/registrations","/feedback":"/feedback","/admin/events/save":"/admin/events","/admin/events/delete":"/admin/events","/admin/students/delete":"/admin/students","/admin/feedback/update":"/feedback","/admin/feedback/delete":"/feedback"}.get(path,"/")
            self.redirect(target,str(exc),"error")
        except Exception as exc:
            self.redirect("/admin" if role=="admin" else "/student",f"Operation failed: {exc}","error")

def main():
    initialize_files()
    refresh_charts()
    server=ThreadingHTTPServer((HOST,PORT),Handler)
    print(f"Campus Event Management Server Started\nOpen: http://{HOST}:{PORT}\nPress Ctrl+C to stop.")
    try: server.serve_forever()
    except KeyboardInterrupt: print("\nServer stopped.")
    finally: server.server_close()

if __name__=="__main__":
    main()
