from datetime import date, timedelta
from services.file_service import initialize_files, read_records, write_records
from services.event_service import save_event
from services.auth_service import create_student
from services.registration_service import register
from services.feedback_service import submit_feedback

initialize_files()
if not read_records("events"):
    today = date.today()
    for i, (name, days, venue, limit, desc) in enumerate([
        ("Python Coding Workshop", 10, "Computer Lab A", 60, "Hands-on Python and problem solving."),
        ("Cultural Night", 18, "Main Auditorium", 200, "An evening of music, dance and performances."),
        ("Data Analytics Seminar", 25, "Seminar Hall", 100, "Explore data analysis and visualization."),
        ("Campus Sports Meet", 32, "College Ground", 150, "Friendly competitions across campus."),
    ], 1):
        save_event({"event_id":f"EVT{i:03d}","event_name":name,"date":(today+timedelta(days=days)).isoformat(),"venue":venue,"max_participants":str(limit),"description":desc})
if not read_records("students"):
    create_student("Aarav Sharma","aarav.demo@gmail.com","BWU/MCA/26/001")
    create_student("Priya Das","priya.demo@gmail.com","BWU/MCA/26/002")
    create_student("Rahul Sen","rahul.demo@gmail.com","BWU/MCA/26/003")
print("Demo data is ready.")
print("Student demo: BWU/MCA/26/001 / aarav.demo@gmail.com")
print("Admin demo: ADMIN001 / admin.demo@gmail.com")
