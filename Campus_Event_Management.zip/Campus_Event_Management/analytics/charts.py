import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from config import CHARTS_DIR
from analytics.analysis import frames

def refresh_charts():
    CHARTS_DIR.mkdir(parents=True, exist_ok=True)
    events, _, regs, feedback = frames()

    # Participation
    labels, values = [], []
    counts = regs.groupby("event_id").size().to_dict() if not regs.empty else {}
    for row in events.to_dict("records"):
        labels.append(row["event_name"][:22])
        values.append(int(counts.get(row["event_id"], 0)))
    fig, ax = plt.subplots(figsize=(8, 3.8))
    ax.bar(labels or ["No events"], values or [0])
    ax.set_title("Event-wise Participation")
    ax.set_ylabel("Active registrations")
    ax.tick_params(axis="x", labelrotation=25)
    fig.tight_layout()
    fig.savefig(CHARTS_DIR / "event_participation.png", dpi=130)
    plt.close(fig)

    # Average ratings
    averages = feedback.groupby("event_id")["rating"].mean().to_dict() if not feedback.empty else {}
    rlabels, rvalues = [], []
    for row in events.to_dict("records"):
        if row["event_id"] in averages:
            rlabels.append(row["event_name"][:22])
            rvalues.append(float(averages[row["event_id"]]))
    fig, ax = plt.subplots(figsize=(8, 3.8))
    ax.bar(rlabels or ["No feedback"], rvalues or [0])
    ax.set_ylim(0, 5)
    ax.set_ylabel("Average rating (1–5)")
    ax.set_title("Average Rating by Event")
    ax.tick_params(axis="x", labelrotation=25)
    fig.tight_layout()
    fig.savefig(CHARTS_DIR / "event_ratings.png", dpi=130)
    plt.close(fig)

    # Rating histogram
    ratings = feedback["rating"].dropna().astype(int).tolist() if not feedback.empty else []
    fig, ax = plt.subplots(figsize=(8, 3.8))
    ax.hist(ratings, bins=[0.5,1.5,2.5,3.5,4.5,5.5], rwidth=0.8)
    ax.set_xticks([1,2,3,4,5])
    ax.set_xlabel("Stars")
    ax.set_ylabel("Feedback count")
    ax.set_title("Rating Distribution")
    fig.tight_layout()
    fig.savefig(CHARTS_DIR / "rating_distribution.png", dpi=130)
    plt.close(fig)

    # Monthly feedback statistics (live, derived from feedback.csv)
    if not feedback.empty:
        monthly = feedback.copy()
        monthly["feedback_date"] = pd.to_datetime(monthly["feedback_date"], errors="coerce")
        monthly = monthly.dropna(subset=["feedback_date"])
        monthly["month"] = monthly["feedback_date"].dt.strftime("%b %Y")
        month_counts = monthly.groupby("month").size()
        month_order = monthly.groupby("month")["feedback_date"].min().sort_values().index
        month_counts = month_counts.reindex(month_order)
    else:
        month_counts = pd.Series(dtype=int)
    fig, ax = plt.subplots(figsize=(8, 3.2))
    if len(month_counts):
        ax.bar(month_counts.index.tolist(), month_counts.values.tolist(), color="#f5823b")
    else:
        ax.bar(["No feedback"], [0], color="#f5823b")
    ax.set_title("Feedback received by month")
    ax.set_ylabel("Number of reviews")
    ax.tick_params(axis="x", labelrotation=25)
    fig.tight_layout()
    fig.savefig(CHARTS_DIR / "feedback_monthly.png", dpi=130)
    plt.close(fig)
