import pandas as pd
import numpy as np
from services.file_service import read_records

def frames():
    events = pd.DataFrame(read_records("events"), columns=["event_id","event_name","date","venue","max_participants","description"])
    students = pd.DataFrame(read_records("students"), columns=["student_id","name","email","student_code"])
    regs = pd.DataFrame(read_records("registrations"), columns=["registration_id","student_id","event_id","registration_date","status"])
    feedback = pd.DataFrame(read_records("feedback"), columns=["feedback_id","student_id","event_id","rating","comment","feedback_date"])
    if not regs.empty:
        regs = regs[regs["status"] == "Registered"]
    if not feedback.empty:
        feedback["rating"] = pd.to_numeric(feedback["rating"], errors="coerce")
        feedback = feedback.dropna(subset=["rating"])
    return events, students, regs, feedback

def dashboard_stats():
    events, students, regs, feedback = frames()
    averages = feedback.groupby("event_id")["rating"].mean().to_dict() if not feedback.empty else {}
    counts = regs.groupby("event_id").size().to_dict() if not regs.empty else {}
    rated = [(str(eid), float(avg)) for eid, avg in averages.items()]
    event_names = dict(zip(events["event_id"], events["event_name"])) if not events.empty else {}
    rated.sort(key=lambda x: x[1], reverse=True)
    return {
        "total_events": len(events),
        "active_registrations": len(regs),
        "unique_participants": int(regs["student_id"].nunique()) if not regs.empty else 0,
        "total_feedback": len(feedback),
        "overall_rating": round(float(np.mean(feedback["rating"].to_numpy(dtype=float))), 2) if not feedback.empty else None,
        "highest": (event_names.get(rated[0][0], rated[0][0]), round(rated[0][1], 2)) if rated else None,
        "lowest": (event_names.get(rated[-1][0], rated[-1][0]), round(rated[-1][1], 2)) if rated else None,
        "registration_counts": counts,
        "averages": averages
    }

def event_table_rows():
    events, _, regs, feedback = frames()
    reg_counts = regs.groupby("event_id").size().to_dict() if not regs.empty else {}
    averages = feedback.groupby("event_id")["rating"].mean().to_dict() if not feedback.empty else {}
    output = []
    for row in events.to_dict("records"):
        eid = row["event_id"]
        row["participants"] = int(reg_counts.get(eid, 0))
        row["available"] = max(0, int(row["max_participants"]) - row["participants"])
        row["average_rating"] = round(float(averages[eid]), 2) if eid in averages else None
        output.append(row)
    return output
