from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
CHARTS_DIR = BASE_DIR / "charts"
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

HOST = "127.0.0.1"
PORT = 8000

# Demo credentials only. Change before any non-demo use.
ADMIN_CODE = "ADMIN001"
ADMIN_EMAIL = "admin.demo@gmail.com"
SESSION_COOKIE = "campus_session"
