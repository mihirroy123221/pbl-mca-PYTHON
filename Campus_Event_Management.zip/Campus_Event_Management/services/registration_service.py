from datetime import date
from services.file_service import read_records, write_records, next_id
from services.event_service import find_event

def all_registrations():
    return read_records("registrations")

def active_for_event(event_id):
    return [r for r in all_registrations() if r["event_id"] == event_id and r["status"] == "Registered"]

def register(student_id, event_id):
    event = find_event(event_id)
    if not event:
        raise ValueError("Invalid event ID.")
    students = read_records("students")
    if not any(s["student_id"] == student_id for s in students):
        raise ValueError("Student account was not found.")
    rows = all_registrations()
    if any(r["student_id"] == student_id and r["event_id"] == event_id and r["status"] == "Registered" for r in rows):
        raise ValueError("You are already registered for this event.")
    if len(active_for_event(event_id)) >= int(event["max_participants"]):
        raise ValueError("This event is full.")
    rows.append({"registration_id": next_id("REG", rows, "registration_id"),
                 "student_id": student_id, "event_id": event_id,
                 "registration_date": date.today().isoformat(), "status": "Registered"})
    write_records("registrations", rows)

def cancel_registration(registration_id, student_id=None):
    rows = all_registrations()
    target = next((r for r in rows if r["registration_id"] == registration_id), None)
    if not target:
        raise ValueError("Registration not found.")
    if student_id and target["student_id"] != student_id:
        raise ValueError("You cannot cancel another student's registration.")
    if target["status"] != "Registered":
        raise ValueError("This registration is already cancelled.")
    target["status"] = "Cancelled"
    write_records("registrations", rows)
