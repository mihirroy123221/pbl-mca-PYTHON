from datetime import date
from models.feedback import Feedback
from services.file_service import read_records, write_records, next_id
from services.event_service import find_event

def all_feedback():
    return read_records("feedback")

def submit_feedback(student_id, event_id, rating, comment):
    if not find_event(event_id):
        raise ValueError("Invalid event ID.")
    regs = read_records("registrations")
    if not any(r["student_id"] == student_id and r["event_id"] == event_id and r["status"] == "Registered" for r in regs):
        raise ValueError("You must have an active registration to submit feedback.")
    rows = all_feedback()
    if any(r["student_id"] == student_id and r["event_id"] == event_id for r in rows):
        raise ValueError("Feedback already submitted for this event. Ask an admin to edit it.")
    try:
        rating = int(rating)
    except (TypeError, ValueError):
        raise ValueError("Rating must be from 1 to 5.")
    obj = Feedback(next_id("FDB", rows, "feedback_id"), student_id, event_id, rating, comment.strip(), date.today().isoformat())
    obj.validate()
    rows.append({"feedback_id": obj.feedback_id, "student_id": student_id, "event_id": event_id,
                 "rating": str(rating), "comment": obj.comment, "feedback_date": obj.feedback_date})
    write_records("feedback", rows)

def update_feedback(feedback_id, rating, comment):
    rows = all_feedback()
    target = next((r for r in rows if r["feedback_id"] == feedback_id), None)
    if not target:
        raise ValueError("Feedback not found.")
    try:
        rating = int(rating)
    except (TypeError, ValueError):
        raise ValueError("Rating must be from 1 to 5.")
    Feedback(target["feedback_id"], target["student_id"], target["event_id"], rating, comment.strip(), target["feedback_date"]).validate()
    target["rating"] = str(rating)
    target["comment"] = comment.strip()
    write_records("feedback", rows)

def delete_feedback(feedback_id):
    rows = all_feedback()
    if not any(r["feedback_id"] == feedback_id for r in rows):
        raise ValueError("Feedback not found.")
    write_records("feedback", [r for r in rows if r["feedback_id"] != feedback_id])
