from datetime import date
from models.event import Event
from services.file_service import read_records, write_records, next_id

def all_events():
    return read_records("events")

def save_event(data, event_id=None):
    rows = all_events()
    event_id = event_id or data.get("event_id", "").strip() or next_id("EVT", rows, "event_id")
    if not event_id:
        raise ValueError("Event ID is required.")
    existing = next((r for r in rows if r["event_id"] == event_id), None)
    try:
        limit = int(data.get("max_participants", ""))
    except ValueError:
        raise ValueError("Maximum participants must be a whole number.")
    event = Event(event_id, data.get("event_name", "").strip(), data.get("date", "").strip(),
                  data.get("venue", "").strip(), limit, data.get("description", "").strip())
    event.validate()
    from services.registration_service import active_for_event
    current_count = len(active_for_event(event_id))
    if limit < current_count:
        raise ValueError(f"Capacity cannot be below the {current_count} active registrations.")
    new_row = {"event_id": event.event_id, "event_name": event.event_name, "date": event.date,
               "venue": event.venue, "max_participants": str(event.max_participants),
               "description": event.description}
    if existing:
        rows = [new_row if r["event_id"] == event_id else r for r in rows]
    else:
        if any(r["event_id"] == event_id for r in rows):
            raise ValueError("Event ID already exists.")
        rows.append(new_row)
    write_records("events", rows)
    return event_id

def delete_event(event_id):
    rows = all_events()
    if not any(r["event_id"] == event_id for r in rows):
        raise ValueError("Invalid event ID.")
    regs = [r for r in read_records("registrations") if r["event_id"] == event_id]
    feedback = [r for r in read_records("feedback") if r["event_id"] == event_id]
    if regs or feedback:
        raise ValueError("Cannot delete an event with registration or feedback history. Keep it for records instead.")
    write_records("events", [r for r in rows if r["event_id"] != event_id])

def find_event(event_id):
    return next((r for r in all_events() if r["event_id"] == event_id), None)
