import csv
from pathlib import Path
from config import DATA_DIR

HEADERS = {
    "events": ["event_id", "event_name", "date", "venue", "max_participants", "description"],
    "students": ["student_id", "name", "email", "student_code", "password_hash"],
    "admins": ["admin_id", "name", "email", "admin_code", "password_hash"],
    "registrations": ["registration_id", "student_id", "event_id", "registration_date", "status"],
    "feedback": ["feedback_id", "student_id", "event_id", "rating", "comment", "feedback_date"],
}

def initialize_files():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for name, header in HEADERS.items():
        path = DATA_DIR / f"{name}.csv"
        if not path.exists():
            with path.open("w", newline="", encoding="utf-8") as f:
                csv.DictWriter(f, fieldnames=header).writeheader()

def read_records(name):
    if name not in HEADERS:
        raise ValueError("Unknown data file.")
    initialize_files()
    path = DATA_DIR / f"{name}.csv"
    try:
        with path.open("r", newline="", encoding="utf-8-sig") as f:
            return list(csv.DictReader(f))
    except (OSError, csv.Error) as exc:
        raise RuntimeError(f"Could not read {name}.csv: {exc}") from exc

def write_records(name, rows):
    if name not in HEADERS:
        raise ValueError("Unknown data file.")
    initialize_files()
    path = DATA_DIR / f"{name}.csv"
    try:
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=HEADERS[name], extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
    except OSError as exc:
        raise RuntimeError(f"Could not write {name}.csv: {exc}") from exc

def next_id(prefix, rows, field):
    numbers = []
    for row in rows:
        value = str(row.get(field, ""))
        if value.startswith(prefix):
            try:
                numbers.append(int(value[len(prefix):]))
            except ValueError:
                pass
    return f"{prefix}{max(numbers, default=0) + 1:03d}"
