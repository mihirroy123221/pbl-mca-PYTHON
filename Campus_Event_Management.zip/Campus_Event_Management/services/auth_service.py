import re
import hashlib
import hmac
import secrets
from services.file_service import read_records, write_records, next_id
from config import ADMIN_CODE, ADMIN_EMAIL

DEMO_ADMIN_PASSWORD = "Admin@12345"
DEMO_STUDENT_PASSWORD = "Student@12345"

def valid_email(email):
    return bool(re.fullmatch(r"[A-Za-z0-9._%+-]+@gmail\.com", email.strip(), re.IGNORECASE))

def hash_password(password):
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 240000)
    return salt.hex() + "$" + digest.hex()

def verify_password(password, stored):
    if not stored:
        return False
    try:
        salt_hex, digest_hex = stored.split("$", 1)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), 240000)
        return hmac.compare_digest(digest.hex(), digest_hex)
    except (ValueError, TypeError):
        return False

def valid_password(password):
    if len(password) < 8 or not re.search(r"[A-Z]", password) or not re.search(r"[a-z]", password) or not re.search(r"\d", password):
        raise ValueError("Password must be at least 8 characters and include uppercase, lowercase and a number.")

def login(code, email, name, role, password):
    code, email, name = code.strip(), email.strip().lower(), name.strip()
    if role not in ("admin", "student"):
        raise ValueError("Choose Admin or Student login.")
    if not re.fullmatch(r"[A-Za-z][A-Za-z .'-]*", name):
        raise ValueError("Enter a valid name using letters only.")
    if not valid_email(email):
        raise ValueError("Use a valid Gmail address, such as example@gmail.com.")
    if not code:
        raise ValueError("ID is required.")
    if role == "admin":
        if code == ADMIN_CODE and email == ADMIN_EMAIL and name.casefold() == "administrator" and password == DEMO_ADMIN_PASSWORD:
            return {"role":"admin", "student_id":"ADMIN", "name":"Administrator", "email":email, "student_code":code}
        for admin in read_records("admins"):
            if (admin["admin_code"].strip().casefold() == code.casefold()
                and admin["email"].strip().casefold() == email
                and admin["name"].strip().casefold() == name.casefold()
                and verify_password(password, admin.get("password_hash", ""))):
                return {"role":"admin", "student_id":admin["admin_id"], "name":admin["name"], "email":email, "student_code":code}
        raise ValueError("Admin name, ID, email or password does not match.")
    for student in read_records("students"):
        if (student["student_code"].strip().casefold() == code.casefold()
            and student["email"].strip().casefold() == email
            and student["name"].strip().casefold() == name.casefold()
            and verify_password(password, student.get("password_hash", ""))):
            return {**student, "role":"student"}
    raise ValueError("Student name, ID, email or password does not match.")

def create_student(name, email, student_code, password):
    from models.student import Student
    rows = read_records("students")
    student = Student(next_id("STU", rows, "student_id"), name.strip(), email.strip().lower(), student_code.strip())
    student.validate()
    if not valid_email(student.email):
        raise ValueError("Use a Gmail address such as example@gmail.com.")
    valid_password(password)
    if any(r["email"].lower() == student.email.lower() for r in rows):
        raise ValueError("Email is already registered.")
    if any(r["student_code"].lower() == student.student_code.lower() for r in rows):
        raise ValueError("Student code already exists.")
    rows.append({"student_id":student.student_id,"name":student.name,"email":student.email,"student_code":student.student_code,"password_hash":hash_password(password)})
    write_records("students", rows)
    return student.student_id

def create_admin(name, email, admin_code, password):
    name, email, admin_code = name.strip(), email.strip().lower(), admin_code.strip()
    if not re.fullmatch(r"[A-Za-z][A-Za-z .'-]*", name):
        raise ValueError("Enter a valid admin name using letters only.")
    if not valid_email(email):
        raise ValueError("Use a Gmail address such as example@gmail.com.")
    if not re.fullmatch(r"ADMIN[0-9]{3,}", admin_code, re.IGNORECASE):
        raise ValueError("Admin code must look like ADMIN002.")
    valid_password(password)
    rows = read_records("admins")
    if email == ADMIN_EMAIL.lower() or any(r["email"].lower() == email for r in rows):
        raise ValueError("Email is already registered.")
    if admin_code.casefold() == ADMIN_CODE.casefold() or any(r["admin_code"].casefold() == admin_code.casefold() for r in rows):
        raise ValueError("Admin code already exists.")
    admin_id = next_id("ADM", rows, "admin_id")
    rows.append({"admin_id":admin_id,"name":name,"email":email,"admin_code":admin_code,"password_hash":hash_password(password)})
    write_records("admins", rows)
    return admin_id
