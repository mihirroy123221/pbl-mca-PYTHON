from dataclasses import dataclass
import re

@dataclass
class Student:
    student_id: str
    name: str
    email: str
    student_code: str

    def validate(self):
        if not self.name.strip() or any(ch.isdigit() for ch in self.name):
            raise ValueError("Name is required and must contain letters, not digits.")
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", self.email.strip()):
            raise ValueError("Enter a valid email address.")
        if not self.student_code.strip():
            raise ValueError("Student code is required.")
