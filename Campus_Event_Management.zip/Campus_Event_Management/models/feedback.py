from dataclasses import dataclass

@dataclass
class Feedback:
    feedback_id: str
    student_id: str
    event_id: str
    rating: int
    comment: str
    feedback_date: str

    def validate(self):
        try:
            rating = int(self.rating)
        except (TypeError, ValueError):
            raise ValueError("Rating must be an integer from 1 to 5.")
        if rating < 1 or rating > 5:
            raise ValueError("Rating must be from 1 to 5.")
