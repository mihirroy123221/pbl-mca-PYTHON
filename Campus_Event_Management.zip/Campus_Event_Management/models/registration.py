from dataclasses import dataclass

@dataclass
class Registration:
    registration_id: str
    student_id: str
    event_id: str
    registration_date: str
    status: str = "Registered"
