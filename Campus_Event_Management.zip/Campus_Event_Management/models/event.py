from dataclasses import dataclass
from datetime import date

@dataclass
class Event:
    event_id: str
    event_name: str
    date: str
    venue: str
    max_participants: int
    description: str = ""

    def validate(self):
        if not self.event_id.strip():
            raise ValueError("Event ID is required.")
        if not self.event_name.strip() or any(ch.isdigit() for ch in self.event_name):
            raise ValueError("Event name is required and must not contain digits.")
        try:
            date.fromisoformat(self.date)
        except ValueError:
            raise ValueError("Date must use YYYY-MM-DD format.")
        if not self.venue.strip():
            raise ValueError("Venue is required.")
        if int(self.max_participants) < 1:
            raise ValueError("Maximum participants must be at least 1.")
